const contenedorPlanes = document.getElementById("planes");
const carritoHTML = document.getElementById("carrito");
const totalHTML = document.getElementById("total");
const btnFinalizar = document.getElementById("btnFinalizar");

let carrito = JSON.parse(localStorage.getItem("carrito")) || [];


fetch("data/planes.json")
  .then(response => response.json())
  .then(planes => {
    planes.forEach(plan => {
      const div = document.createElement("div");
      div.className = "col-md-4";

      div.innerHTML = `
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">${plan.nombre}</h5>
            <p class="card-text">${plan.descripcion}</p>
            <p class="fw-bold">$${plan.precio}</p>
            <button class="btn btn-primary w-100">Agregar</button>
          </div>
        </div>
      `;

      div.querySelector("button").addEventListener("click", () => {
        agregarAlCarrito(plan);
      });

      contenedorPlanes.appendChild(div);
    });
  });


function agregarAlCarrito(plan) {
  carrito.push(plan);
  actualizarCarrito();

  Swal.fire({
    icon: "success",
    title: "Plan agregado",
    text: `${plan.nombre} agregado al carrito`
  });
}


function actualizarCarrito() {
  carritoHTML.innerHTML = "";
  let total = 0;

  carrito.forEach((item, index) => {
    total += item.precio;

    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";

    li.innerHTML = `
      ${item.nombre} - $${item.precio}
      <button class="btn btn-sm btn-danger">❌</button>
    `;

    li.querySelector("button").addEventListener("click", () => {
      eliminarDelCarrito(index);
    });

    carritoHTML.appendChild(li);
  });

  totalHTML.textContent = total;
  localStorage.setItem("carrito", JSON.stringify(carrito));
}


function eliminarDelCarrito(index) {
  carrito.splice(index, 1);
  actualizarCarrito();
}


btnFinalizar.addEventListener("click", () => {
  if (carrito.length === 0) {
    Swal.fire({
      icon: "warning",
      title: "Carrito vacío",
      text: "Agregá al menos un plan"
    });
    return;
  }

  Swal.fire({
    title: "¿Confirmar compra?",
    text: "Se procesará tu pedido",
    icon: "question",
    showCancelButton: true,
    confirmButtonText: "Comprar",
    cancelButtonText: "Cancelar"
  }).then(result => {
    if (result.isConfirmed) {
      carrito = [];
      localStorage.removeItem("carrito");
      actualizarCarrito();

      Swal.fire({
        icon: "success",
        title: "Compra realizada",
        text: "Gracias por tu compra 💪"
      });
    }
  });
});

actualizarCarrito();
