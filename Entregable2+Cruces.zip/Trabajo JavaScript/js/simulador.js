/* simulador.js
   Objetivo: reemplazar prompts/alerts por interaccion DOM + eventos
*/

// Key para localStorage
const STORAGE_KEY = 'simulador_entregable2_cruces_v1';

// Consejos (se muestran en DOM)
const CONSEJOS = [
  "Dormí al menos 7-8 horas por noche para una buena recuperación.",
  "Mantené una buena hidratación durante todo el día.",
  "No entrenes todos los días con la misma intensidad: alterná fuerza y descanso activo.",
  "Controlá tu técnica antes de aumentar el peso.",
  "La constancia vale más que la perfección.",
  "Comé proteínas en cada comida para favorecer la ganancia muscular.",
  "No te olvides del calentamiento y estiramiento post-entrenamiento."
];

/* ---------- Helpers / Validaciones ---------- */
function mostrarMensaje(texto, tipo = 'info') {
  // tipo: 'info', 'success', 'danger', 'warning'
  const cont = document.getElementById('mensajeContenedor');
  cont.innerHTML = `
    <div class="alert alert-${tipo} alert-dismissible fade show" role="alert">
      ${texto}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>`;
}

function validarNombre(nombre) {
  if (!nombre || !/^[a-zA-Z\sáéíóúÁÉÍÓÚñÑ]+$/.test(nombre.trim())) return "Ingresá un nombre válido (solo letras).";
  return null;
}
function validarNumero(valor, campo, min = 0.0001) {
  if (valor === '' || isNaN(valor) || Number(valor) <= min) return `Ingresá un número válido para ${campo}.`;
  return null;
}

/* ---------- Storage ---------- */
function cargarRegistros() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error parseando storage', e);
    return [];
  }
}
function guardarRegistros(registros) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(registros));
}
function agregarRegistro(registro) {
  const regs = cargarRegistros();
  regs.unshift(registro); // agrego al inicio
  guardarRegistros(regs);
}

/* ---------- Lógica del IMC ---------- */
function calcularCategoriaIMC(imc) {
  if (imc < 18.5) return "Bajo peso";
  if (imc < 25) return "Peso saludable";
  if (imc < 30) return "Sobrepeso";
  return "Obesidad";
}

function calcularIMCObjeto({ nombre, edad, peso, altura }) {
  const imc = Number((peso / (altura * altura)).toFixed(2));
  return {
    nombre,
    edad: Number(edad),
    peso: Number(peso),
    altura: Number(altura),
    imc,
    categoria: calcularCategoriaIMC(imc),
    fecha: new Date().toISOString()
  };
}

/* ---------- Renderizado ---------- */
function renderConsejos() {
  const ul = document.getElementById('listaConsejos');
  ul.innerHTML = '';
  CONSEJOS.forEach(c => {
    const li = document.createElement('li');
    li.textContent = c;
    ul.appendChild(li);
  });
}

function renderResultado(reg) {
  const cont = document.getElementById('resultadoCard');
  cont.classList.remove('d-none');
  cont.innerHTML = `
    <h6>Resultado para ${reg.nombre}</h6>
    <p>IMC: <strong>${reg.imc}</strong> — <em>${reg.categoria}</em></p>
    <p>Edad: ${reg.edad} • Peso: ${reg.peso} kg • Altura: ${reg.altura} m</p>
    <small class="text-muted">Guardado: ${new Date(reg.fecha).toLocaleString()}</small>
  `;
}

function renderHistorial() {
  const area = document.getElementById('historialArea');
  const list = document.getElementById('historialList');
  const registros = cargarRegistros();
  if (registros.length === 0) {
    area.classList.add('d-none');
    list.innerHTML = '<p class="text-muted">No hay registros aún.</p>';
    return;
  }

  area.classList.remove('d-none');
  list.innerHTML = '';

  // tabla 
  const table = document.createElement('table');
  table.className = 'table table-sm';
  table.innerHTML = `
    <thead>
      <tr>
        <th>Fecha</th><th>Nombre</th><th>IMC</th><th>Categoría</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tbody = table.querySelector('tbody');
  registros.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${new Date(r.fecha).toLocaleString()}</td>
      <td>${r.nombre}</td>
      <td>${r.imc}</td>
      <td>${r.categoria}</td>
    `;
    tbody.appendChild(tr);
  });

  list.appendChild(table);
}

/* ---------- Eventos y flujo principal ---------- */
function iniciarSimulador() {
  // Mostrar el área del simulador y cargar historial
  document.getElementById('simuladorArea').classList.remove('d-none');
  document.getElementById('bienvenidaCard').classList.add('d-none');
  renderConsejos();
  renderHistorial();
  mostrarMensaje('Simulador iniciado correctamente.', 'success');
}

document.addEventListener('DOMContentLoaded', () => {
  // Botón iniciar
  const startBtn = document.getElementById('startBtn');
  startBtn.addEventListener('click', iniciarSimulador);

  // Formulario
  const form = document.getElementById('imcForm');
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // leer inputs
    const nombre = document.getElementById('nombre').value.trim();
    const edad = document.getElementById('edad').value;
    const peso = document.getElementById('peso').value;
    const altura = document.getElementById('altura').value;

    // limpiar errores anteriores
    document.getElementById('error-nombre').textContent = '';
    document.getElementById('error-edad').textContent = '';
    document.getElementById('error-peso').textContent = '';
    document.getElementById('error-altura').textContent = '';

    // validaciones
    let hayError = false;
    const errNombre = validarNombre(nombre);
    if (errNombre) {
      document.getElementById('error-nombre').textContent = errNombre;
      hayError = true;
    }
    const errEdad = validarNumero(edad, 'edad', 0);
    if (errEdad) {
      document.getElementById('error-edad').textContent = errEdad;
      hayError = true;
    }
    const errPeso = validarNumero(peso, 'peso', 0);
    if (errPeso) {
      document.getElementById('error-peso').textContent = errPeso;
      hayError = true;
    }
    const errAlt = validarNumero(altura, 'altura', 0.4);
    if (errAlt) {
      document.getElementById('error-altura').textContent = errAlt;
      hayError = true;
    }

    if (hayError) {
      mostrarMensaje('Revisá los campos marcados en rojo.', 'danger');
      return;
    }

    // crear objeto de registro
    const registro = calcularIMCObjeto({ nombre, edad, peso, altura });
    // guardar en storage
    agregarRegistro(registro);
    // renderizar resultado e historial
    renderResultado(registro);
    renderHistorial();
    mostrarMensaje(`IMC calculado y guardado para ${nombre}.`, 'success');

    // opcional: limpiar form (no obligatorio)
    // form.reset();
  });

  // mostrar consejos
  const consejosBtn = document.getElementById('mostrarConsejosBtn');
  consejosBtn.addEventListener('click', () => {
    const area = document.getElementById('consejosArea');
    area.classList.toggle('d-none');
  });

  // limpiar historial
  const limpiarBtn = document.getElementById('limpiarHistorialBtn');
  limpiarBtn.addEventListener('click', () => {
    if (!confirm('¿Querés borrar todo el historial?')) return;
    localStorage.removeItem(STORAGE_KEY);
    renderHistorial();
    mostrarMensaje('Historial borrado.', 'warning');
  });

  // Si ya hay registros al cargar la página, mostralos pero mantené el simulador oculto hasta que el usuario presione iniciar.
  const regs = cargarRegistros();
  if (regs.length > 0) {
    renderHistorial();
  }
});
